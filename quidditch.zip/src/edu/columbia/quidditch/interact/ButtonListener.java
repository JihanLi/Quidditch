package edu.columbia.quidditch.interact;

/**
 * Bind actions to buttons
 * 
 * @author Yuqing Guan
 * 
 */
public interface ButtonListener
{
	public void onClick();
}
